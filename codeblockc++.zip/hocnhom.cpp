#include<bits/stdc++.h>
using namespace std;
bool check(int n)
{
     if(n==1) {return false;}
     if(n==2) {return true;}
     for(int i=2;i<=sqrt(n);i++){
          if(n%i==0){
               return false;
          }
     }
     return true;
}
int daonguoc(int n)
{
    int dem=0,s=0,x=n;
     while(x>0){
          x=x/10;
          dem++;
     }
     while(n>0){
          s+=(n%10)*(pow(10,dem-1));
          n=n/10;
          dem--;
     }
    return s;
}
int main(){
//    freopen("hi.inp","r",stdin);
//    freopen("hi.out","w",stdout);
     int a1,a2,k=0;
     cin>>a1>>a2;
     for(int i=a1;i<=a2;i++){
     	if(check(i)&&check(daonguoc(i))){
     		k++;
		 }
	 }
	 cout<<k;
}
