#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("hi.inp","r",stdin);
    freopen("hi.out","w",stdout);
    int n;
    cin>>n;
    int a[n+1][n+1],dp[n+1][n+1];
    for(int i=1;i<=n;i++){
     for(int j=1;j<=i;j++){
          cin>>a[i][j];
     }
    }
    dp[1][1]=a[1][1];
    dp[2][1]=a[2][1]*a[1][1];
    dp[2][2]=a[2][2]*a[1][1];
    for(int i=3;i<=n;i++){
     dp[i][1]=a[i][1]*dp[i-1][1];
     dp[i][i]=a[i][i]*dp[i-1][i-1];
     for(int j=2;j<i;j++){
          dp[i][j]=a[i][j]*max(dp[i-1][j-1],dp[i-1][j]);
    }
    }
    int max=dp[n][1];
    for(int i=1;i<=n;i++){
     if(dp[n][i]>=max){
          max=dp[n][i];
     }
    }
    cout<<max;
    return 0;
}

