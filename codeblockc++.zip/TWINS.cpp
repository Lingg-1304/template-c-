#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("TWINS.inp","r",stdin);
    freopen("TWINS.out","w",stdout);
    long long n,k;
	int dem=0;
    cin>>n>>k;
    int dp[n+1];
    memset(dp,0,sizeof(dp));
    dp[0]=1;
    dp[1]=1;
    for(int i=2;i<=sqrt(n);i++){
    	for(int j=i*i;j<=n;j+=i){
    		dp[j]=1;
		}
	}
	for(int i=0;i<=n;i++){
		for(int j=0;j<i;j++){
			if(dp[i]==0 && dp[j]==0 && (i-j)==k){
				dem++;
			}
		}
	}
	cout<<dem;
    return 0;
}
