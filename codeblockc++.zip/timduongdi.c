#include <stdio.h>
#include <conio.h>
#include <iostream>
#define FileIn "Bai4.inp"
int Dem = 0;      //Đếm số đường đi
int*L;         //Lưu lại đường đã đi
char*DanhDau;   //Đánh dấu đỉnh đã đi
int **A,n,D,C;
/*Dọc file dữ liệu theo yêu cầu của chương trình*/
void Doc_File(){
   FILE*f = fopen(FileIn,"rb");
   fscanf(f,"%d%d%d",&n,&D,&C);      //Đọc số đỉnh n,  đỉnh D và C
   cout<<"Ma Tran Lien Ket Tuong Ung.\n"<<D<<" "<<C<<endl;
   *A = new int [n];
   for(int i =0;i<n;i++) {
      A[i] = new int [n];
      for(int j =0;j<n;j++) {
         fscanf(f,"%d",&A[i][j]);
         cout<<A[i][j]<<" ";
      }
      cout<<endl;
   }
   fclose(f);
   D--;      //Giảm D và C vì ta xử lý số đỉnh từ 0 đến n-1
   C--;
}
/*Khởi tạo các tham số ban đầu cho chương trình*/
void KhoiTao() {
   DanhDau = new char [n];
   L = new int [n];
   for (int i = 0; i<n; i++) {   //Tất cả các đỉnh chưa được đánh dấu
      DanhDau[i] = 0;
      L[i] = 0;
   }
   DanhDau[D] = 1;      //Đánh dấu đỉnh đầu tiên
   L[0] = D;         //Lưu lại đỉnh đầu tiên là đỉnh xuất phát
}
void InDuongDi(int SoCanh) {
   Dem++;
   cout<<endl<<D+1;
   for (int i = 1; i<SoCanh; i++)
      cout<<" -> "<<L[i]+1;
}
/*Thủ tục đệ quy tìm kiếm đường đi*/
void TimKiem(int SoCanh) {
   if(L[SoCanh-1] == C)     //Xuất nếu đỉnh tìm từ lần tìm kiếm trước bằng C
    InDuongDi(SoCanh);
   else {
    for(int i = 0; i<n; i++)
      if( A[L[SoCanh-1]][i]>0 && DanhDau[i] == 0 ){
         L[SoCanh] = i;      //Lưu lại đỉnh đi qua
         DanhDau[i] = 1;      //Đánh dấu đỉnh đi qua
         TimKiem(SoCanh+1);   //Tìm kiếm đỉnh tiếp theo
         L[SoCanh] = 0;
         DanhDau[i] = 0;      //Phục hồi đỉnh đỉnh đã đi qua
      }
   }
}
/*Chương trình chính*/
void main() {
   Doc_File();   KhoiTao();
   cout<<"Duong di tu "<<D+1<<" den "<<C+1;
   TimKiem(1);
   if(Dem==0)      cout<<" khong co";
   delete*A,DanhDau,L;
   getch();
}
