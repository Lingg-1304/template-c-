#include <bits/stdc++.h>

using namespace std;

int main ()     {

          string str;     cin >> str;
     
          long long n = str.size (), x = 0;
    
          for (int i = 0; i < n; i++)     {
                   
                      if (str [i] >= '0' && str [i]<='9')       x = x*10  +str [i]-'0';
                      else {     

                            for (int j = 1; j <= x; j++)     cout << str [i];      
                            if (x == 0)   cout << str [i];      x = 0;
                   }
          }
   return 0;
}
