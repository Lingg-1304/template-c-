#include<bits/stdc++.h>;
using namespace std;
vector<int> v[10000];
int thao;
int demv=0;
set<int> set;
void check(){
	set<int> cc;
	for(int x : v[demv]){
		cc.insert(x);
	}
	int kq[10000];
	for(int x : cc){
		int dem=0;
		for(int y : v[demv]){
			if(x==y){
				dem++;
			}
		}
		kq[x]=dem;
	}
	
	for(int x : set){
		if(k[x]-kq[x]==1 || k[x]-kq[x]==0) thao=1;
		else thao=0;
	}
}
int main(){
	//input
	int n; cin>>n;
	int a[n+1];
	for(int i=1;i<=n;i++){
		cin>>a[i];
		set.insert(a[i]);
	}
	
	//dem so luong phan tu k[x]
	int k[100];
	for(int x : set){
		int dem=0;
		for(int i=1;i<=n;i++){
			if(x==a[i]){
				dem++;
			}
		}
		k[x]=dem;
	}
	
	
	for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			v[demv].insert(a[j]);
			check();
			if(thao==1){
				cout<<j-i+1;
				break;
			}
			demv++;
		}
	}
}
