#include<bits/stdc++.h>
using namespace std;
int sokitu(string ss, char k){
	int dem=0;
	for(int i=0;i<ss.size();i++){
		if(ss[i]==k){
			dem++;
		}
	}
	return dem;
}
bool check(int n,int k){
	if(n==k) return true;
	else return false;
}

int main(){
  int k=-2;
	char d[256];
	FILE *f;
	f=fopen("hi.inp","r");
	while(feof(f)==0){
		k++;
		fgets(d,256,f);
	}
  freopen("hi.inp","r",stdin);
  freopen("hi.out","w",stdout);
// input
    
    string s;
    cin>>s;
    string ss[k];
    for(int i=0;i<k;i++) cin>>ss[i];
    
//xu ly string goc
    int kitu[26];
    memset(kitu,0,sizeof(kitu));
    int dem=0;
    for(char i='a';i<='z';i++){
    	for(int j=0;j<s.size();j++){
    		if(i==s[j]){
    		   kitu[dem]++;	
			}
		}
		dem++;
	}
	
//xu ly string con
    for(int i=0;i<k;i++){
    	int plus=0;
    	int test=0;
    	for(char j='a';j<='z';j++){
    		if(check(kitu[plus],sokitu(ss[i],j))==false){
    			test++;
			}
			plus++;
		}
		if(test==0) cout<<1<<endl;
		else cout<<0<<endl;
	}
	cout<<k<<"asdasd";
}
