#include<bits/stdc++.h>
using namespace std;
using ll = long long;
int n,m,a[501][501],res=1,kq=-1e9;
void inp(){
    cin>>n>>m;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            cin>>a[j][i];
        }
    }
}
void loang(int i,int j){
	a[i][j]=0;
	if(a[i-1][j]==1){
		loang(i-1,j);
		res++;
	}
	if(a[i+1][j]==1){
		res++;
		loang(i+1,j);
	}
	if(a[i][j-1]==1){
		res++;
		loang(i,j-1);
	}
	if(a[i][j+1]==1){
		res++;
		loang(i,j+1);
	}
}
int main(){
    ios_base::sync_with_stdio(0); 
    cin.tie(0);
    inp();
    for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(a[i][j]==1){
				loang(i,j);
				kq=max(kq,res);
				res=1;
			}
		}
	}
	cout<<kq;
}
