#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,max;
	cin>>n;
	int a[n],b[n],s[n];
	for(int i=1;i<=n;i++){
		cin>>a[i]>>b[i];
	}
	s[1]=b[1]-a[1];
	for(int i=1;i<=n;i++){
		s[i+1]=s[i]-a[i+1]+b[i+1];
	}
	max=s[1];
	for(int i=1;i<=n;i++){
		if(s[i]>=max){
			max=s[i];
		}
	}
	cout<<max;
}
