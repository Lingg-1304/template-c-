#include<bits/stdc++.h>
using namespace std;
void sinh(int a[100],int n){
    for(int i=1;i<=n;i++){
          cout<<a[i];
     }
    for(int j=n;j>=a;j--){
          if (a[j]=0){
               a[j]=1;
          }
     }
}
int main(){
     int n,a[1000];
     cin>>n;
     for(int i=1;i<=n;i++){
          a[i]=0;
     }
     for(int i=n;i>=1;i--){
          sinh(a[i],n);
     }
}
