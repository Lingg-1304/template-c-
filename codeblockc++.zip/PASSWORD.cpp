#include<bits/stdc++.h>
using namespace std;
bool check(string s){
	int dem=0;
	for(int i=0;i<s.size();i++){
		if(s[i]>='A'&&s[i]<='Z'){
			dem++;
			break;
		}
	}
	for(int i=0;i<s.size();i++){
		if(s[i]>='a'&&s[i]<='z'){
			dem++;
			break;
		}
	}
	for(int i=0;i<s.size();i++){
		if(s[i]>='0'&&s[i]<='9'){
			dem++;
			break;
		}
	}
	if(dem==3&&s.size()>=6){
		return true;
	}
	else return false;
}

int main(){
    freopen("PASSWORD.inp","r",stdin);
    freopen("PASSWORD.out","w",stdout);
    string s;
    cin>>s;
    int dem=0;
    set<string> k;
    for(int i=0;i<=s.size()-5;i++){
    	for(int j=6;j<=s.size()-i;j++){
    		k.insert(s.substr(i,j));
		}
	}
//	for( string x : k) cout<<x<<endl;
//	cout<<endl;
	for(set<string>::iterator it=k.begin();it!=k.end();it++){
		if(check(*it)) dem++;
	}
	cout<<dem;
    return 0;
}
