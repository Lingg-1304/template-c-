#include<bits/stdc++.h>
using namespace std;
int a[100001];
int dp[10001][10001];
int main(){
	freopen("subseq.inp","r",stdin);
	freopen("subseq.out","w",stdout);
	int  n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++) cin>>a[i];
	memset(dp,0,sizeof(dp));
	for(int i=1;i<=k;i++){
		dp[k][k]+=a[i];
	}
    int maxn=dp[k][k];
	for(int i=k;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			dp[i][j]=dp[i][j-1]-a[j-i]+a[j];
			maxn=max(maxn,dp[i][j]);
		}
		dp[i+1][i+1]=dp[i][i]+a[i+1];
	}

	cout<<maxn;
}
