#include<bits/stdc++.h>
using namespace std;
int main(){
//    freopen("hi.inp","r",stdin);
//    freopen("hi.out","w",stdout);
    int n;
    cin>>n;
    long long a[n+1];
    int dp[n+1];
    for(int i=1;i<=n;i++) {
    	cin>>a[i];
    	dp[i]=1;
	}
    for(int i=1;i<=n;i++){
    	for(int j=1;j<i;j++){
    		if(a[i]>a[j] && a[i]%a[j]==0){
    			dp[i]=max(dp[j]+1,dp[i]);
			}
		}
	}
	cout<<*max_element(dp+1,dp+n+1);
    return 0;
}
