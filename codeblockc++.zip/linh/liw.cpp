#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> II;
int main(){
	freopen("liw.inp","r",stdin);
	freopen("liw.out","w",stdout);
	map<long long, int> mp;
	int n,m,dem=0; cin>>n>>m;
	pair<long long,long long> g[m];
	vector<II> vpe;
	for(int i=0;i<n;i++){
		long long k; cin>>k;
		mp[k]=1;
	}
	for(int i=0;i<m;i++) cin>>g[i].first;
	for(int i=0;i<m;i++) cin>>g[i].second;
	sort(g,g+m);
	for(int i=0;i<m;i++){
		if(mp[g[i].second]==1){
			dem++;
			vpe.push_back(g[i]);
		}
	}
	cout<<dem<<endl;
	for(int i=0;i<vpe.size();i++){
		cout<<vpe[i].second<<" "<<vpe[i].first<<endl;
	}
}
