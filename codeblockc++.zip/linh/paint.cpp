#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("paint.inp","r",stdin);
	freopen("paint.out","w",stdout);
	int n; cin>>n;
	for(int k=0;k<n;k++){
		int it; cin>>it;
		int a[it+1][4];
		for(int i=1;i<=it;i++){
			for(int j=1;j<=3;j++){
				cin>>a[i][j];
			}
		}
		for(int i=2;i<=it;i++){
			a[i][1]+=min(a[i-1][2],a[i-1][3]);
			a[i][2]+=min(a[i-1][1],a[i-1][3]);
			a[i][3]+=min(a[i-1][1],a[i-1][2]);
		}
		cout<<*min_element(a[it]+1,a[it]+1+3)<<endl;
	}
}
