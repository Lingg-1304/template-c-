#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("ptc.inp","r",stdin);
	freopen("ptc.out","w",stdout);
    map<int,int> mp;
    vector<int> v;
    int n; cin>>n;
    int k[n];
    set<int> se;
    for(int i=0;i<n;i++){
    	cin>>k[i];
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<k[i];j++){
			int x; cin>>x;
			if(mp[x]==i){
				mp[x]++;
				se.insert(x);
			}
		}
	}
	for(set<int>::iterator it=se.begin();it!=se.end();it++){
		if(mp[*it]==n){
			v.push_back(*it);
			break;
		}
	}
	if(v.size()>0) cout<<v[0];
	else cout<<"x";
}
