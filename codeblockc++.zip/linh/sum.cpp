#include<bits/stdc++.h>
using namespace std;
int a[100001];
int dp[100001];
int check(int n){
	int s=0;
	while(n>0){
		s+=n%10;
		n/=10;
	}
	if(s>=10) return check(s);
	else return s;
}
int main(){
	freopen("sum.inp","r",stdin);
	freopen("sum.out","w",stdout);
	for(int i=1;i<=100000;i++){
		a[i]=check(i);
	}
	dp[1]=1;
	for(int i=2;i<=100000;i++){
		dp[i]=dp[i-1]+a[i];
	}
	int q;
	cin>>q;
	while(q>0){
		int l,r;
		cin>>l>>r;
		cout<<dp[r]-dp[l-1]<<endl;
		q--;
	}
}
