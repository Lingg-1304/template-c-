#include<bits/stdc++.h>
#define maxn 5001
using namespace std;
int a[maxn][maxn];
int n,dem,d,x,y;
void inp(){
	cin>>n;
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cin>>a[i][j];
		}
	}
}
void t(){
	dem=0;
	int i,j;
	i=1;
	while(i<=n){
		j=1;
		while(j<=n){
			if(a[i][j]==1){
				d=1; x=i ; y=j;
				while(a[x+1][y]==1){
					d++; x++;
				}
				if(d>dem) dem=d;
				d=1; x=i ; y=j;
				while(a[x][y+1]==1){
					d++; y++;
				}
				if(d>dem) dem=d;
				d=1; x=i ; y=j;
				while(a[x-1][y+1]==1){
					d++; y++; x--;
				}
				if(d>dem) dem=d;
				d=1; x=i ; y=j;
				while(a[x+1][y+1]==1){
					d++; x++; y++;
				}
				if(d>dem) dem=d;
			}
			j++;
		}
		i++;
	}
	cout<<dem;
}
int main(){
	freopen("dendien.inp","r",stdin);
	freopen("dendien.out","w",stdout);
	inp();
	t();
}
