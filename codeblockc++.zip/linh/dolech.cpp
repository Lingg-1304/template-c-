#include<bits/stdc++.h>
using namespace std;
int a[100000];
int main(){
	freopen("dolech.inp","r",stdin);
	freopen("dolech.out","w",stdout);
	int k;
	int n,dem=0;
	map<int,int> mp;
	cin>>n>>k;
	for(int i=0;i<n;i++){
		cin>>a[i];
		mp[a[i]]++;
	}
	for(int i=0;i<n;i++){
		dem+=mp[a[i]-k];
		dem+=mp[a[i]+k];
	}
	cout<<dem/2;
}
