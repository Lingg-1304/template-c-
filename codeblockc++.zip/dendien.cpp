#include<bits/stdc++.h>
using namespace std;
int n,a[5001][5001],b[5001][5001],c[5001][5001],d[5001][5001];
int res=0;
int kq[4];
void inp(){
	cin>>n;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			cin>>a[i][j];
			b[i][j]=a[i][j];
			c[i][j]=a[i][j];
			d[i][j]=a[i][j];
		}
	}
}

void loangngang(int i,int j){
	res++;
	a[i][j]=0;
	if(j<=n){
	if(a[i][j+1]==1){
		loangngang(i,j+1);
	}
	}
	kq[0]=max(res,kq[0]);
}

void loangdoc(int i,int j){
	res++;
	b[i][j]=0;
	if(i<=n){
	if(b[i+1][j]==1){
		loangdoc(i+1,j);
	}
	}
	kq[1]=max(res,kq[1]);
}

void loangcheo1(int i,int j){
	res++;
	c[i][j]=0;
	if(i<=n && j<=n){
	if(c[i+1][j+1]==1){
		loangcheo1(i+1,j+1);
	}
	}
	kq[2]=max(res,kq[2]);
}

void loangcheo2(int i,int j){
	res++;
	d[i][j]=0;
	if(i<=n && j<=n && j>0){
	if(d[i+1][j-1]==1){
		loangcheo2(i+1,j-1);
	}
	}
	kq[3]=max(res,kq[3]);
}
int main(){
	freopen("dendien.inp","r",stdin);
	freopen("dendien.out","w",stdout);
    ios_base::sync_with_stdio(0); 
    cin.tie(0);
    inp();
    for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(a[i][j]==1){
				loangngang(i,j);
				res=0;
			}
			res=0;
			if(b[i][j]==1){
				loangdoc(i,j);
				res=0;
			}
			res=0;
			if(c[i][j]==1){
				loangcheo1(i,j);
				res=0;
			}
			res=0;
			if(d[i][j]==1){
				loangcheo2(i,j);
				res=0;
			}
		}
	}
	cout<<*max_element(kq,kq+4);
}
