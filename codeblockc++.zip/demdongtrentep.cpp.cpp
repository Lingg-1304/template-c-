#include<bits/stdc++.h>
using namespace std;
int main(){
	int dem=-1;
	char d[1000];
	FILE *f;
	f=fopen("hi.inp","r");
	while(!feof(f)){
		dem++;
		fgets(d,1000,f);
	}
	freopen("hi.out","w",stdout);
	cout<<dem;
}
