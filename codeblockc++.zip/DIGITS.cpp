#include<bits/stdc++.h>
using namespace std;
int a[9];
void check(int n){
	while(n>0){
		a[n%10]++;
		n/=10;
	}
}
int main(){
//  freopen("digits.inp","r",stdin);
//  freopen("digits.out","w",stdout);
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
    	check(i);
	}
	cout<<"0 "<<a[0]<<endl;
	cout<<"1 "<<a[1]<<endl;
	cout<<"2 "<<a[2]<<endl;
	cout<<"3 "<<a[3]<<endl;
	cout<<"4 "<<a[4]<<endl;
	cout<<"5 "<<a[5]<<endl;
	cout<<"6 "<<a[6]<<endl;
	cout<<"7 "<<a[7]<<endl;
	cout<<"8 "<<a[8]<<endl;
	cout<<"9 "<<a[9]<<endl;
}
