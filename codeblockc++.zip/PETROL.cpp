#include<bits/stdc++.h>
using namespace std;
int main(){
//    freopen("PETROL.inp","r",stdin);
//    freopen("PETROL.out","w",stdout);
    long long d;
    int n,dem=0;
    cin>>n>>d;
    long long x[n],h[n];
    pair<long long,long long> pe[n];
    for(int i=0;i<n;i++){
    	cin>>x[i]>>h[i];
    	pe[i] = make_pair(x[i],h[i]);
	}
	sort(pe,pe+n);
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			if((pe[j].first-pe[i].first)>=d && (pe[j].second-2*(pe[i].second))>=0 ){
				dem++;
				cout<<pe[i].first;
			}
			
		}
	}
	cout<<dem;
    return 0;
}
//6 4
//10 3
//6 2
//5 3
//9 7
//3 6
//11 2
