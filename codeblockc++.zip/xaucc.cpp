#include<bits/stdc++.h>
using namespace std;
int main()
{
     string s;
     cin>>s;
     long long dem=0;
     for(int i=0;i<s.size();i++){
          if(s[i]>='0'&&s[i]<='9'){
               dem=dem*10+s[i]-'0';
          }
          else{
               for(int j=1;j<=dem;j++){
                    cout<<s[i];
               }
               if(dem==0){cout<<s[i];}
               dem=0;
          }
      }
}

