#include<bits/stdc++.h>
#define ft first
#define se second
using namespace std;
bool cmp(pair<float,float> x,pair<float,float> y){
	float ox=sqrt((x.ft)*(x.ft)+(x.se)*(x.se));
	float oy=sqrt((y.ft)*(y.ft)+(y.se)*(y.se));
	if(ox<oy){
		return true;
	}
	else if(ox==oy){
		if(x.ft<y.ft) return true;
		if(x.ft==y.ft && x.se<y.se) return true;
	}
	else return false;
}
int main(){
	int n;
	cin>>n;
	pair<float,float> a[n];
	for(int i=0;i<n;i++){
		cin>>a[i].ft>>a[i].se;
	}
	sort(a,a+n,cmp);
	for(int i=0;i<n;i++) cout<<a[i].ft<<" "<<a[i].se<<endl;
}
