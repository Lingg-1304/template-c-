#include<bits/stdc++.h>
using namespace std;
int main(){
	//input
	int n; cin>>n;
	int a[n+1];
	set<int> set;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		set.insert(a[i]);
	}
	
	//dem so luong phan tu k[x]
	int k[1000];
	for(int x : set){
		int dem=0;
		for(int i=1;i<=n;i++){
			if(x==a[i]){
				dem++;
			}
		}
		k[x]=dem;
	}
	int linh[1000],p=0;
	for(int i=1;i<n;i++){
		for(int j=1;j<=n-i+1;j++){
			int kq=0;
			for(int x : set){
				int demtest=0;
				for(int z=j;z<=j+i-1;z++){
				//cout<<a[z];
				if(x == a[z]){
					demtest++;
				}
				}
				if(k[x]-demtest==1 || k[x]-demtest==0){
					kq++;
				}
				else break;
			}
			if(kq==n-i){
			cout<<i;
			break;
		}
			//cout<<endl;
		}
		p++;
		//cout<<endl;
	}
	//cout<<*min_element(linh,linh+p);
}

