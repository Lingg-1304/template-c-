#include<bits/stdc++.h>
using namespace std;
int main(){
  freopen("LOTT.inp","r",stdin);
  freopen("LOTT.out","w",stdout);
   int n,k,s=0;
   cin>>n>>k;
   int p[n+1];
   for(int i=1;i<=n;i++) cin>>p[i];
   long long a,b;
   cin>>a>>b;
   int dem[b+1];
   for(long long i=a;i<=b;i++) dem[i]=0;  
    for(long long i=a;i<=b;i++){
   		for(int j=1;j<=n;j++){
   			if(i%p[j]==0){
   				dem[i]++;
			   }
		   }
	}
	for(long long i=a;i<=b;i++){
		if(dem[i]==k){
			s++;
		}
	}
	cout<<s;
}
