#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cin>>n;
	int a[n],s[n];
	for(int i=1;i<=n;i++) cin>>a[i]; 
	for(int i=1;i<=n;i++) s[i]=0;
		for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			if(a[i]>a[j]){
			
			}
		}
	}
	int max=s[1];
	for(int i=1;i<n;i++){
		if(s[i]>=max){
			max=s[i];
		}
	}
	cout<<max+1;
}
