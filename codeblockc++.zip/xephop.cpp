#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("box.inp","r",stdin);
    freopen("box.out","w",stdout);
    int n;
    cin>>n;
    pair<int,int> pt[n];
    int a[n],b[n],dp[n];
     for(int i=0;i<n;i++){
       cin>>a[i]>>b[i];
       if(b[i]>a[i]){
          pt[i] = make_pair(b[i],a[i]);
       }
       else{
     pt[i] = make_pair(a[i],b[i]);
       }
     dp[i]=1;
    }
    sort(pt,pt+n);
    for(int i=0;i<n;i++){
     for(int j=0;j<i;j++){
          if(pt[i].second>pt[j].second && (pt[i].first>pt[j].first)){
               dp[i]=max(dp[i],dp[j]+1);
          }
     }
    }
    cout<< *max_element(dp,dp+n);
}

