#include <bits/stdc++.h>
#define el cout<<"\n"
#define pb push_back
#define all(x) begin(x), end(x)
#define sz(x) (ll)(x).size()
#define NAME "temp"
using namespace std;
using ll = long long;
using ld = long double;
const ll INF=1000000000;
typedef vector<pair<ll,ll>> vii;
typedef vector<ll> vi;
typedef pair<ll,ll> pii;
const ll maxn=1001001;
ll n,a[maxn],cnt1[maxn],cnt2[maxn],res=INF,cur2=0;
int main()
{
    cin.tie(0)->sync_with_stdio(0);
    cin>>n;
    for(ll i=1;i<=n;++i)
    {
        cin>>a[i];
    }
    ll r=n+1;
    while(r>1)
    {
        if(cnt2[a[r-1]]==0)
        {
            --r;
            ++cnt2[a[r]];
            ++cur2;
        }
        else
        {
            break;
        }
    }
    res=min(res,n-cur2);
    for(ll i=1;i<=n;++i)
    {
        if(cnt1[a[i]])break;
        ++cnt1[a[i]];
        while(r<=n&&cnt2[a[i]])
        {
            --cnt2[a[r]];
            --cur2;
            ++r;
        }
        res=min(res,n-i-cur2);
    }
    cout<<res;
    return 0;
}
 
