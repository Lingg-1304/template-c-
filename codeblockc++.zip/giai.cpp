#include <bits/stdc++.h>

using namespace std;
typedef pair<int,int> II;
typedef pair<int,II> III;
III h[1001];int n,f[1001];
bool bao(int x, int y){
    return(h[x].second.first>h[y].second.first&&h[x].second.second>h[y].second.second);
}
void sinhtest(){
    freopen("xephop.inp","w",stdout);
    n=1000;
    cout<<n<<endl;
    for(int i=1; i<=n; i++) cout<<rand()%1000<<" "<<rand()%1000<<endl;
}
int main()
{
    //sinhtest();
    freopen("cc.inp","r",stdin);
    freopen("cc.out","w",stdout);
    cin>>n;
    for(int i=1; i<=n; i++){
        int dai, rong;
        cin>>dai>>rong;
        if(dai<rong) swap(dai,rong);
        h[i]=III(dai*rong,II(dai,rong));
        f[i]=1;
    }
    sort(h+1,h+n+1);

    int kq=1;
    for(int i=2; i<=n; i++)
        for(int j=i-1;j>=1; j--)
        if(bao(i,j)){
            f[i]= max(f[i],f[j]+1);
            kq=max(kq,f[i]);
        }
    cout<<kq;
    return 0;
}
