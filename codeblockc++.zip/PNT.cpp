#include <bits/stdc++.h>
using namespace std;
int uoc(int n){
	int s=1;
	for(int i=2;i<=sqrt(n);i++){
		int dem=0;
    	while(n%i==0){
    		n/=i;
    		dem++;
		}
		s*=dem+1;
	}
	if(n!=1){
		s*=2;
	}
	return s;
}
int unprime(int n){
	int kq[n+1];
	for(int i=2;i<=n;i++){
		kq[i]=uoc(i);
	}
	int max=*max_element(kq+2,kq+n+1);
	for(int i=n;i>=2;i--){
		if(kq[i]==max){
			return i;
			break;	
		}
	}
}
int main(){
//    freopen("hi.inp","r",stdin);
//    freopen("hi.out","w",stdout);
    int n;
    cin >> n;
    int a[n];
    for(int i=0;i<n;i++){
    	cin>>a[i];
	}
	for(int i=0;i<n;i++){
		cout<<unprime(a[i])<<endl;
	}
}
