#include<bits/stdc++.h>
using namespace std;
bool checknt(long long k)
{
     for(int i=2;i<=sqrt(k);i++){
          if(k%i==0){
               return false;
               break;
          }
     }
     return true;
}
int check(long long x)
{
     long long sont=x*x+x*(x-1)+(x-1)*(x-1);
     if(checknt(sont)){
          return 1;
     }
     else return 0;
}
int main()
{
     int n;
     long long a[101];
     cin>>n;
     for(int i=1;i<=n;i++) cin>>a[i];
     for(int i=1;i<=n;i++){
          if(a[i]==1) cout<<"0"<<endl;
          else cout<<check(a[i])<<endl;
     }
}

