#include <bits/stdc++.h>
using namespace std;
int main(){
	vector<int> v={};
	cout<<v.size()<<endl;
	//cout<<*lower_bound(v.begin(),v.end(),10);
}
