#include<bits/stdc++.h>
using namespace std;
using ll = long long;
bool check(ll n){
    float s=sqrt(n);
    if(s==(int)sqrt(n)) return true;
    else return false;
}
int main(){
    ios_base::sync_with_stdio(0); 
    cin.tie(0);
    ll a,b;
    cin>>a>>b;
    for(ll i=a;i<=b;i++){
    	if(check(i)) cout<<i<<" ";
	}
}
